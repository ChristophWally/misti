import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
// Five premium Italian voices organized by gender for natural selection
const FEMALE_VOICES = [
  "it-IT-IsabellaMultilingualNeural",
  "it-IT-PalmiraNeural"
];
const MALE_VOICES = [
  "it-IT-GiuseppeMultilingualNeural",
  "it-IT-DiegoNeural",
  "it-IT-CalimeroNeural"
];
const ALL_VOICES = [
  ...FEMALE_VOICES,
  ...MALE_VOICES
];
serve(async (req)=>{
  try {
    // Parse the webhook payload from dictionary table insert
    const { record } = await req.json();
    console.log('Processing audio generation for word:', record.italian);
    // Initialize Supabase client with service role key for full access
    const supabase = createClient(Deno.env.get('SUPABASE_URL'), Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'));
    // Safety check: prevent duplicate generation
    const { data: existingMetadata, error: checkError } = await supabase.from('word_audio_metadata').select('*').eq('word_id', record.id).single();
    if (existingMetadata) {
      console.log('Audio already exists for word:', record.italian);
      return new Response(JSON.stringify({
        success: true,
        message: 'Audio already exists',
        existing_voice: existingMetadata.azure_voice_name
      }));
    }
    // Intelligent voice selection based on word gender
    let selectedVoice;
    const tags = record.tags || [];
    if (tags.includes('feminine')) {
      // Feminine nouns use female voices
      selectedVoice = FEMALE_VOICES[Math.floor(Math.random() * FEMALE_VOICES.length)];
      console.log('Feminine noun detected, selected female voice:', selectedVoice);
    } else if (tags.includes('masculine')) {
      // Masculine nouns use male voices
      selectedVoice = MALE_VOICES[Math.floor(Math.random() * MALE_VOICES.length)];
      console.log('Masculine noun detected, selected male voice:', selectedVoice);
    } else {
      // All other word types use random selection from all voices
      selectedVoice = ALL_VOICES[Math.floor(Math.random() * ALL_VOICES.length)];
      console.log('Non-gendered word, selected random voice:', selectedVoice);
    }
    // Create SSML for natural pronunciation with slight rate reduction
    const ssml = `
      <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="it-IT">
        <voice name="${selectedVoice}">
          <prosody rate="0.9" pitch="0%">
            ${record.italian}
          </prosody>
        </voice>
      </speak>
    `.trim();
    // Get Azure Speech Service region and key from environment
    const azureRegion = Deno.env.get('AZURE_SPEECH_REGION') // e.g., 'eastus'
    ;
    const azureKey = Deno.env.get('AZURE_SPEECH_KEY');
    if (!azureRegion || !azureKey) {
      throw new Error('Azure Speech Service configuration missing');
    }
    // Call Azure Text-to-Speech API (protected by your budget system)
    console.log('Calling Azure TTS for:', record.italian);
    const ttsResponse = await fetch(`https://${azureRegion}.tts.speech.microsoft.com/cognitiveservices/v1`, {
      method: 'POST',
      headers: {
        'Ocp-Apim-Subscription-Key': azureKey,
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-16khz-128kbitrate-mono-mp3',
        'User-Agent': 'Misti-Italian-Learning-App'
      },
      body: ssml
    });
    if (!ttsResponse.ok) {
      const errorText = await ttsResponse.text();
      console.error('Azure TTS API error:', ttsResponse.status, errorText);
      throw new Error(`Azure TTS failed: ${ttsResponse.status} - ${errorText}`);
    }
    // Get audio data and metadata
    const audioBuffer = await ttsResponse.arrayBuffer();
    const filename = `audio_${record.id}.mp3`;
    const azureRequestId = ttsResponse.headers.get('X-RequestId') || 'unknown';
    console.log('Generated audio:', filename, 'Size:', audioBuffer.byteLength, 'bytes');
    // Upload audio file to Supabase Storage
    const { error: uploadError } = await supabase.storage.from('audio-files').upload(filename, new Blob([
      audioBuffer
    ], {
      type: 'audio/mpeg'
    }), {
      cacheControl: '3600',
      upsert: false // Prevent overwriting existing files
    });
    if (uploadError) {
      console.error('Storage upload error:', uploadError);
      throw new Error(`Storage upload failed: ${uploadError.message}`);
    }
    // Calculate approximate duration (rough estimate: 16khz = ~8 chars/second for Italian)
    const estimatedDuration = record.italian.length / 8;
    // Store metadata in database for voice consistency and analytics
    const { error: metadataError } = await supabase.from('word_audio_metadata').insert({
      word_id: record.id,
      azure_voice_name: selectedVoice,
      audio_filename: filename,
      file_size_bytes: audioBuffer.byteLength,
      duration_seconds: estimatedDuration,
      generation_method: 'azure-tts',
      character_count: record.italian.length,
      azure_request_id: azureRequestId,
      play_count: 0,
      needs_regeneration: false,
      generated_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });
    if (metadataError) {
      console.error('Metadata insert error:', metadataError);
    // Don't throw here - audio file was created successfully
    // Could implement cleanup logic here if needed
    }
    console.log('Successfully generated audio for:', record.italian);
    return new Response(JSON.stringify({
      success: true,
      word: record.italian,
      voice: selectedVoice,
      filename: filename,
      file_size: audioBuffer.byteLength,
      azure_request_id: azureRequestId
    }), {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Audio generation error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
});
